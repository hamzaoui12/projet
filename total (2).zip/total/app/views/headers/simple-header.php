<div class="container-fluid">
  <div class="blog-nav row">
    <nav class="navbar navbar-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="./index.php">
          <img src="./img/Logo_Total.png" alt="" width="150" height="150" class="d-inline-block align-text-top">
        </a>
      </div>
    </nav>
  </div>
</div>