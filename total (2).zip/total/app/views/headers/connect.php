<div class="container-fluid">
  <!-- Navigation -->
  <div class="blog-nav row">
    <nav class="navbar navbar-expand navbar-light ">
      <div class="container-fluid">
        <a class="navbar-brand" href="http://localhost/total/index.php">
          <img src="./img/Logo_Total.png" alt="" width="150" height="150" class="d-inline-block align-text-top">
        </a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="http://localhost/total/index.php"><strong>Accueil</strong></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="http://localhost/total/partenaire.php">Partenaires</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" aria-current="page profile" href="http://localhost/total/compte.php">Club TotalEnergies</a>
            </li>
          </ul>
          <form class="d-flex">
            <input class="form-control me-2" name="q" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-danger" type="submit">Search</button>
        </form>
        </div>
      </div>
    </nav>
  </div>
</div>